from datetime import datetime

class TimeDate:
    def __init__(self, time=False, date=False):
        self.time = time
        self.date = date

    def check_string(self, user_input):
        user_input = user_input.lower()
        if "time" in user_input:
            self.time = True
        if "date" in user_input:
            self.date = True
        now = datetime.now()

        if self.time and self.date:
            return ("Current Date and Time:", now.strftime("%Y-%m-%d %H:%M:%S"))
        elif self.time:
            return("Current Time:", now.strftime("%H:%M:%S"))
        elif self.date:
            return("Current Date:", now.strftime("%Y-%m-%d"))
        else:
            return("No request made for time or date.")


# Example Usage
if __name__ == "__main__":
    user_input = input("Enter your request: ")
    td = TimeDate()
    td.check_string(user_input)
