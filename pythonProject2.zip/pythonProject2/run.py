import os
import time
import threading
from gtts import gTTS
import speech_recognition as sr
from playsound import playsound

class VoiceAssistant:
    def speak(self, text, lang='en'):
        """Converts text to speech using gTTS and plays the sound."""
        try:
            tts = gTTS(text=text, language=lang)
            filename = "temp_audio.mp3"
            tts.save(filename)
            # Play sound in a separate thread to avoid blocking the program
            threading.Thread(target=playsound, args=(filename,)).start()
            # Optionally remove the file after some time to avoid clutter
            time.sleep(len(text) / 5)  # Approximate sleep time based on text length
            os.remove(filename)
        except Exception as e:
            print(f"Error in speak function: {e}")

    def listen(self, lang='en'):
        """Listens to user input via microphone and returns the text."""
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")  
            recognizer.adjust_for_ambient_noise(source)  # Adjusting for ambient noise
            try:
                audio = recognizer.listen(source, timeout=15, phrase_time_limit=10)  # Adjusting timeouts
                text = recognizer.recognize_google(audio, language=lang)
                print(f"You said: {text}")
                return text
            except sr.UnknownValueError:
                print("Sorry, I didn't understand that.")
                return "Sorry, I didn't understand that."
            except sr.RequestError as e:
                print(f"Speech Recognition service error: {e}")
                return ""
            except Exception as e:
                print(f"Error in listen function: {e}")
                return ""
