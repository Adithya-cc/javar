import imaplib
import email
from email.header import decode_header
from plyer import notification
import time
import threading

# Your email credentials
username = "adithya.totallycold@gmail.com"
password = "hlsf abep gqyd faic"

# Connect to the email server
mail = imaplib.IMAP4_SSL("imap.gmail.com")

# Log in to the server
try:
    mail.login(username, password)
except imaplib.IMAP4.error as e:
    print("Login failed:", e)
    exit()

# Select the mailbox you want to read (INBOX is the default)
mail.select("inbox")


def get_email_subjects():
    """Fetch and display the subjects of the top 5 emails."""
    status, messages = mail.search(None, "ALL")
    email_ids = messages[0].split()

    # Get the top 5 emails
    top_5_ids = email_ids[-5:]

    for i, email_id in enumerate(top_5_ids):
        status, msg_data = mail.fetch(email_id, "(RFC822)")
        for response_part in msg_data:
            if isinstance(response_part, tuple):
                msg = email.message_from_bytes(response_part[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding if encoding else "utf-8")
                print(f"Email {i + 1}: {subject}")


def read_particular_email(email_index):
    """Read a particular email by its index."""
    status, messages = mail.search(None, "ALL")
    email_ids = messages[0].split()

    email_id = email_ids[-(int(email_index) + 1)]  # Convert to correct ID
    status, msg_data = mail.fetch(email_id, "(RFC822)")

    for response_part in msg_data:
        if isinstance(response_part, tuple):
            msg = email.message_from_bytes(response_part[1])
            subject, encoding = decode_header(msg["Subject"])[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding if encoding else "utf-8")
            from_ = msg.get("From")
            print(f"Subject: {subject}")
            print(f"From: {from_}")

            # Read the content of the email
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get("Content-Disposition"))
                    if "attachment" not in content_disposition:
                        if content_type == "text/plain":
                            body = part.get_payload(decode=True).decode()
                            print(f"Body: {body}")
            else:
                body = msg.get_payload(decode=True).decode()
                print(f"Body: {body}")


def read_unread_emails():
    """Fetch unread emails."""
    status, messages = mail.search(None, 'UNSEEN')  # Filter for unread emails
    email_ids = messages[0].split()

    top_unread = email_ids[:3]  # Get the top 3 unread emails
    for i, email_id in enumerate(top_unread):
        status, msg_data = mail.fetch(email_id, "(RFC822)")
        for response_part in msg_data:
            if isinstance(response_part, tuple):
                msg = email.message_from_bytes(response_part[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding if encoding else "utf-8")
                print(f"Unread Email {i + 1}: {subject}")


def notify_new_email():
    """Notify the user when a new email arrives."""
    while True:
        status, messages = mail.search(None, "UNSEEN")  # Search for unread emails
        email_ids = messages[0].split()

        if email_ids:  # If there are unread emails
            notification.notify(
                title="New Email",
                message="You have a new email in your inbox!",
                timeout=10
            )
        time.sleep(10)  # Check for new emails every 10 seconds


def main():
    """Main program to interact with the user and check notifications."""
    # Start the email notification thread
    notification_thread = threading.Thread(target=notify_new_email, daemon=True)
    notification_thread.start()

    while True:
        print("\nOptions:")
        print("1. View top 5 email subjects")
        print("2. Read a particular email")
        print("3. View unread emails (Top 3)")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            get_email_subjects()
        elif choice == "2":
            email_index = input("Enter the email index to read (0 for latest): ")
            read_particular_email(email_index)
        elif choice == "3":
            read_unread_emails()
        elif choice == "4":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
