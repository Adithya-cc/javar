import platform
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import webbrowser
import os
import time

# Conditionally import pygetwindow for Windows only
if platform.system() == "Windows":
    import pygetwindow as gw
else:
    gw = None  # Placeholder for unsupported platforms
    print("PyGetWindow is not supported on Linux. Spotify window closing functionality will be skipped.")

class SpotifyPlayer:
    def __init__(self, log_file="last_played_song.txt"):
        self.sp = spotipy.Spotify(
            auth_manager=SpotifyOAuth(
                client_id="e2686916e8d448fda98f500701760e25",
                client_secret="2a06b974f94c407a84c62f131b976213",
                redirect_uri="http://localhost:8888/callback",
                scope="user-read-playback-state user-modify-playback-state"
            )
        )
        self.log_file = log_file
        self.current_url = None  # To keep track of the current opened track URL

    def search_and_play(self, track_name):
        """Search for a track and open it in the browser."""
        try:
            # Search for the track by name
            results = self.sp.search(q=track_name, type="track", limit=1)
            if results["tracks"]["items"]:
                track = results["tracks"]["items"][0]
                track_name = track["name"]
                artist_name = track["artists"][0]["name"]
                print(f"Playing '{track_name}' by {artist_name}...")

                # Open the track in the browser
                web_url = track["external_urls"]["spotify"]
                print(f"Opening the track in your browser: {web_url}")
                webbrowser.open(web_url)  # Opens the track in the default browser
                self.current_url = web_url  # Store the current URL to close later

                # Save the song name and window title to the file in the format "Artist Name - Title"
                with open(self.log_file, "w") as file:
                    file.write(f"{artist_name} - {track_name}")

            else:
                print("Track not found.")
        except Exception as e:
            print(f"Error: {e}")
            print("Unable to play the track.")

    def stop_playback(self):
        """Close the Spotify app or web page."""
        # Read the last played song from the file
        with open(self.log_file, "r") as file:
            last_played_song = file.read().strip()

        if last_played_song:
            print(f"Stopping playback and closing window for: {last_played_song}")
            # Close any Spotify-related window
            self.close_spotify_window(last_played_song)

            # Clear the content of the file after closing the window
            with open(self.log_file, "w") as file:
                file.truncate(0)

    def close_spotify_window(self, last_played_song):
        """Close any Spotify app window or web page window and print all open windows."""
        if gw:
            try:
                # Print all open window titles
                all_windows = gw.getAllTitles()  # Get titles of all open windows
                print("Open windows:", all_windows)
                for window in all_windows:
                    print(window)

                # Check for any open window with the last played song name in its title
                spotify_windows = [window for window in gw.getWindowsWithTitle(last_played_song)]
                if spotify_windows:
                    print(f"Spotify window for '{last_played_song}' is open. Closing the window...")
                    spotify_windows[0].close()  # Close the first matching Spotify window found
                else:
                    print(f"No Spotify window with the title '{last_played_song}' is open.")

            except Exception as e:
                print(f"Error closing Spotify window: {e}")
        else:
            print("Spotify window closing is skipped for Linux. Please close the browser manually.")

# Example usage
if __name__ == "__main__":
    player = SpotifyPlayer()

    while True:
        # Display menu and get user input
        print("\nSpotify Player Menu:")
        print("1. Play a song")
        print("2. Stop playback and close Spotify window")

        action = input("Enter a choice (1-2): ").strip()

        if action == "1":
            track_name = input("Enter the song name: ")
            player.search_and_play(track_name)
        elif action == "2":
            player.stop_playback()
        else:
            print("Invalid choice. Please choose a valid option (1-2).")

