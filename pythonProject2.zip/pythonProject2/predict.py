from transformers import BertTokenizer, BertForSequenceClassification
import torch

# Load the trained model and tokenizer
model = BertForSequenceClassification.from_pretrained("intent_classifier_model")
tokenizer = BertTokenizer.from_pretrained("intent_classifier_model")


# Function to predict intent
def predict_intent(text):
    # Tokenize the input text
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)

    # Get the model's prediction
    with torch.no_grad():
        outputs = model(**inputs)

    logits = outputs.logits
    predicted_class = torch.argmax(logits, dim=1).item()

    # Mapping class label to actual command name (based on the labels you trained)
    label_map = {
        0: "Alarm",
        1: "Reminder",
        2: "Timer",
        3: "Weather",
        4: "Time and Date",
        5: "Facts",
        6: "Jokes",
        7: "Music",
        8: "Mail Read",
        9: "News Read",
        10: "Interactive Story Telling",
        11: "Voice-Activated Notes",
        12: "Simple Calculation"
    }

    # Return the predicted intent label
    return label_map.get(predicted_class, "Unknown Command")


# Continuous input loop
while True:
    user_input = input("Enter a command: ")

    if user_input.lower() in ["exit", "quit"]:
        print("Exiting the program.")
        break

    # Predict the intent based on user input
    predicted_intent = predict_intent(user_input)

    # Print the predicted intent
    print(f"Detected Intent: {predicted_intent}")
