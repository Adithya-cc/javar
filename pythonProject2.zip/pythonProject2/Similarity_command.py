import requests
from difflib import SequenceMatcher
from concurrent.futures import ThreadPoolExecutor

class SimilarityProcessor:
    def __init__(self, api_url, api_key):
        self.api_url = api_url
        self.api_key = api_key
        self.predefined_dict = {
            "alarm": [
        "Set alarm at",
        "Create an alarm for",
        "Schedule an alarm at",
        "Set a wake-up alarm at",
        "Can you set an alarm for"
    ],
    "reminder": [
        "Set reminder for",
        "Create a reminder for",
        "Remind me about",
        "Schedule a reminder for",
        "Can you set a reminder for"
    ],
    "weather": [
        "What is the weather?",
        "How's the weather?",
        "What's the weather like today?",
        "Tell me the weather forecast",
        "Can you check the weather?"
    ],
    "timer": [
        "Set timer for",
        "Create a timer for",
        "Start a timer for",
        "Set a countdown timer for",
        "Can you start a timer for"
    ],
    "facts": [
        "Tell me a fact",
        "Share an interesting fact",
        "Give me a fun fact",
        "Do you know any facts?",
        "Can you tell me a fact?"
    ],
    "joke": [
        "Tell me a joke",
        "Share a funny joke",
        "Do you know any jokes?",
        "Make me laugh with a joke",
        "Can you tell me a funny joke?"
    ],
    "music": [
        "Play some music/song",
        "Start playing music/song",
        "Can you play music/song?",
        "Begin playing some tunes/music/song",
        "Play a song/music for me"
    ],
    "stop music": [
        "Stop the music/song",
        "Pause the music/song",
        "Can you stop the music/song?",
        "Turn off the music/song",
        "Stop playing music/song"
    ],
    "notes": [
        "Take notes",
        "Write down a note",
        "Can you jot this down?",
        "Start taking notes",
        "Record this note for me"
    ],
    "recipe1": [
        "Find a recipe",
        "Search for a recipe",
        "Look up a recipe",
        "Help me find a recipe",
        "Can you suggest a recipe?"
    ],
    "recipe2": [
        "Suggest Indian recipes by meal time",
        "What are some Indian recipes for dinner?",
        "Recommend Indian dishes for lunch",
        "Can you suggest Indian breakfast recipes?",
        "Find Indian meal ideas for me"
    ],
    "time": [
        "What is the time?",
        "Can you tell me the time?",
        "What time is it now?",
        "Tell me the current time",
        "Check the time for me"
    ],
    "date": [
        "What is the date?",
        "Can you tell me today's date?",
        "What's today's date?",
        "Tell me the current date",
        "Check the date for me"
    ],
    "timendate": [
        "What is the time and date?",
        "Can you tell me the time and date?",
        "What's the current time and date?",
        "Tell me today's time and date",
        "Check both time and date for me"
    ],
    "translate": [
        "Translate the following",
        "Can you translate this?",
        "Help me translate this text",
        "Translate this sentence for me",
        "What does this mean in another language?"
    ],
    "calculation": [
        "Calculate the following",
        "Can you do this calculation?",
        "Help me solve this math problem",
        "Work out this calculation for me",
        "Do this calculation, please"
    ],
    "riddle": [
        "Tell me a riddle",
        "Share a riddle with me",
        "Do you know any riddles?",
        "Can you tell me a riddle?",
        "Challenge me with a riddle"
    ]
            # Add other entries as needed
        }

    def fetch_similarity(self, input_text, variation):
        body = {'text_1': input_text, 'text_2': variation}
        response = requests.post(self.api_url, headers={'X-Api-Key': self.api_key}, json=body)

        if response.status_code == requests.codes.ok:
            response_data = response.json()
            return response_data.get('similarity', 0.0)
        return 0.0

    def local_similarity(self, input_text, variation):
        return SequenceMatcher(None, input_text, variation).ratio()

    def get_best_match(self, input_text, pre_screen_threshold=0.5, top_n=3):
        input_text = input_text.lower()
        highest_similarity = 0.0
        best_match = None
        similarities = []

        candidates = []
        for key, variations in self.predefined_dict.items():
            for variation in variations:
                score = self.local_similarity(input_text, variation.lower())
                if score >= pre_screen_threshold:
                    candidates.append((key, variation, score))

        candidates = sorted(candidates, key=lambda x: x[2], reverse=True)[:top_n]

        with ThreadPoolExecutor() as executor:
            future_to_key = {}
            for key, variation, _ in candidates:
                future = executor.submit(self.fetch_similarity, input_text, variation)
                future_to_key[future] = key

            for future in future_to_key:
                similarity = future.result()
                similarities.append(similarity)
                if similarity > highest_similarity:
                    highest_similarity = similarity
                    best_match = future_to_key[future]

        if similarities:
            mean_similarity = sum(similarities) / len(similarities)
            if highest_similarity > mean_similarity:
                return best_match
        return None

    def process_user_input(self, user_input):
        best_key = self.get_best_match(user_input)

        if best_key and best_key in user_input.lower():
            return best_key
        elif best_key:
            return None
        else:
            return None

# Main function
def main():
    api_key = 'sBebQvvfkR98Id/En4EGJA==rbpIYD4ZPrsHnPAS'  # Replace with your actual API key
    processor = SimilarityProcessor(api_url, api_key)

    while True:
        user_input = input("Enter a sentence to check for similarity (or type 'exit' to quit): ").strip()
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting the program. Goodbye!")
            break

        # Process user input
        result = processor.process_user_input(user_input)
        return result

