import requests

# API URL and Key
api_url = 'https://api.api-ninjas.com/v1/riddles'
api_key = 'sBebQvvfkR98Id/En4EGJA==rbpIYD4ZPrsHnPAS'
while 1:
    try:
        # Send GET request to the API
        response = requests.get(api_url, headers={'X-Api-Key': api_key})

        # Check for successful response
        if response.status_code == requests.codes.ok:
            riddles = response.json()  # Parse JSON response
            for riddle in riddles:
                print(f"Question: {riddle['question']}")
                print(f"Answer: {riddle['answer']}")
                print("-" * 40)
        else:
            print("Error:", response.status_code, response.text)

    except requests.exceptions.RequestException as e:
        print("An error occurred:", e)
    a = input("")

