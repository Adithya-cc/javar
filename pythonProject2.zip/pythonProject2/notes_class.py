from notion_client import Client

# Initialize the Notion client with your integration token
notion = Client(auth="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")

try:
    # Query databases or pages (Note: Databases are a specific type of page in Notion)
    response = notion.databases.query(database_id="16f942db49668024857ce262fc751eb2")

    # Print out the response for debugging
    print(response)

except Exception as e:
    print(f"Error occurred: {str(e)}")
