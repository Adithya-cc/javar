import pyttsx3
import requests
import json
import time
import speech_recognition as sr


def speak(text):
    """Speak the given text using pyttsx3."""
    engine.say(text)
    engine.runAndWait()


def fetch_news(query):
    """Fetch news based on the user's query."""
    url = f'https://newsapi.org/v2/everything?q={query}&apiKey=f40ea34a3a694f35a730ae9315cb8c45'

    try:
        response = requests.get(url)
        response.raise_for_status()
        news = response.json()
    except requests.exceptions.RequestException as e:
        speak("Cannot access the link. Please check your internet connection or API key.")
        print(f"Error: {e}")
        return None

    return news


def process_news(news):
    """Process and read out the news."""
    if 'articles' in news and news['articles']:
        for i, new in enumerate(news['articles'][:5], start=1):  # Limit to the first 5 articles
            title = new.get('title', 'No Title Available')
            description = new.get('description', 'No Description Available')

            # Speak and display the title
            print(f"News {i} Title: {title}")
            speak(f"News {i} Title: {title}")

            # Speak and display the description
            print(f"News {i} Description: {description}\n")
            speak(f"News {i} Description: {description}")

            print("..............................................................")
            time.sleep(2)
    else:
        speak("No articles found.")
        print("No articles found or invalid API response.")


def listen_to_user():
    """Listen to the user's query and return it as text."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak("Hello! Please tell me what news you're interested in.")
        print("Listening...")
        try:
            audio = recognizer.listen(source)
            user_query = recognizer.recognize_google(audio)
            print(f"User said: {user_query}")
            return user_query
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that. Could you repeat?")
        except sr.RequestError:
            speak("Sorry, I couldn't connect to the speech recognition service.")
    return None


# Initialize the text-to-speech engine
engine = pyttsx3.init()
rate = engine.getProperty('rate')
engine.setProperty('rate', rate + 10)

volume = engine.getProperty('volume')
engine.setProperty('volume', max(volume - 0.60, 0.0))

voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id if len(voices) > 1 else voices[0].id)

# Main script logic
if __name__ == "__main__":
    #user_query = listen_to_user()
    if True:
        news = fetch_news(query=input("enter:"))
        if news:
            process_news(news)
