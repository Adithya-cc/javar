import json
from datetime import datetime, timedelta
import time


class Reminder:
    def __init__(self, log_file="reminders.txt"):
        self.log_file = log_file

    def read_reminders(self):
        try:
            with open(self.log_file, "r") as file:
                reminders = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            reminders = []
        return reminders

    def save_reminders(self, reminders):
        with open(self.log_file, "w") as file:
            json.dump(reminders, file, indent=4)

    def add_reminder(self, time_input, description, date_input=None):
        now = datetime.now()
        try:
            if date_input:
                reminder_time = datetime.strptime(f"{date_input} {time_input}", "%Y-%m-%d %H:%M")
            else:
                reminder_time = datetime.strptime(time_input, "%H:%M")
                reminder_time = reminder_time.replace(year=now.year, month=now.month, day=now.day)
                if reminder_time < now:
                    reminder_time += timedelta(days=1)

            reminders = self.read_reminders()

            # Check for duplicates
            for reminder in reminders:
                existing_reminder_time = datetime.strptime(reminder["time"], "%Y-%m-%d %H:%M")
                if existing_reminder_time == reminder_time and reminder["active"]:
                    print(f"A reminder is already set for {reminder_time.strftime('%Y-%m-%d %H:%M')}.")
                    return

            reminders.append({
                "time": reminder_time.strftime("%Y-%m-%d %H:%M"),
                "description": description,
                "active": True
            })
            self.save_reminders(reminders)
            print(f"Reminder added for {reminder_time.strftime('%Y-%m-%d %H:%M')}: {description}")
        except ValueError:
            print("Invalid time format. Use 'HH:MM' or provide a valid date and time.")

    def deactivate_reminder(self, date_time):
        reminders = self.read_reminders()
        for reminder in reminders:
            if reminder["time"] == date_time:
                if not reminder["active"]:
                    print(f"Reminder for {date_time} is already deactivated.")
                    return
                reminder["active"] = False
                self.save_reminders(reminders)
                print(f"Reminder for {date_time} deactivated.")
                return
        print(f"No reminder found for {date_time}.")

    def get_next_reminder(self):
        reminders = self.read_reminders()
        active_reminders = [r for r in reminders if r["active"]]
        if not active_reminders:
            return None
        active_reminders.sort(key=lambda x: datetime.strptime(x["time"], "%Y-%m-%d %H:%M"))
        return active_reminders[0]

    def reminder_function(self):
        while True:
            next_reminder = self.get_next_reminder()
            if not next_reminder:
                time.sleep(10)  # Check periodically if there are no active reminders
                continue

            reminder_time = datetime.strptime(next_reminder["time"], "%Y-%m-%d %H:%M")
            now = datetime.now()

            if reminder_time < now:
                print(f"Reminder: {next_reminder['description']} (Scheduled for {next_reminder['time']})")
                self.deactivate_reminder(next_reminder["time"])
                continue

            time_to_wait = (reminder_time - now).total_seconds()
            if time_to_wait <= 0:
                print(f"\nReminder: {next_reminder['description']} (Scheduled for {next_reminder['time']})")
                self.deactivate_reminder(next_reminder["time"])
            else:
                time.sleep(1)

    def run(self):
        """Run the reminder checking functionality."""
        try:
            self.reminder_function()
        except KeyboardInterrupt:
            print("\nReminder system stopped.")

