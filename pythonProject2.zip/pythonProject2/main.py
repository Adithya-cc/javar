import threading
from alarm_class_program import AlarmClock
from reminder_class import Reminder
from timer import Timer
from weather_class import Weather
from facts_class import FactsAndJokes
from music_class import SpotifyPlayer
from Similarity_command import SimilarityProcessor
from gtts import gTTS
import speech_recognition as sr
from ollama import chat
from playsound import playsound
from run import VoiceAssistant
from chat_bot import ChatBot
from action_handler import handle_user_action  # Import the handle_user_action function

va = VoiceAssistant()

# Alarm runner function
def alarm_runner(alarm_clock):
    """Run the alarm function continuously in its own thread."""
    alarm_clock.run()

def reminder_runner(reminder):
    """Run the reminder function continuously in its own thread."""
    reminder.run()

# User interface function
def user_interface(similarity_processor, alarm_clock, reminder, timer, weather, facts_and_jokes, song_player, chatbot):
    while True:
        user_input = va.listen()  # Listen for user input
        
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting the program. Goodbye!")
            va.speak("Goodbye!")
            break

        # Handle the action based on user input
        handled = handle_user_action(user_input, va, similarity_processor, alarm_clock, reminder, timer, weather, facts_and_jokes, song_player)

        if not handled:
            # If no action was taken by handle_user_action, proceed with conversational mode
            print("Switching to conversational mode...")
            ollama_response = chatbot.chat_with_ollama(user_input)
            print(f"Ollama: {ollama_response}")
            va.speak(ollama_response)

# Main program logic
if __name__ == "__main__":
    api_url = 'https://api.api-ninjas.com/v1/textsimilarity'
    api_key = 'sBebQvvfkR98Id/En4EGJA==rbpIYD4ZPrsHnPAS'  # Replace with your actual API key
    similarity_processor = SimilarityProcessor(api_url, api_key)

    alarm_clock = AlarmClock(sound_file=r"old_alarm_sound.mp3")
    reminder = Reminder()
    timer = Timer()
    weather = Weather()
    facts_and_jokes = FactsAndJokes()
    song_player = SpotifyPlayer()
    chatbot = ChatBot()  # Instantiate the ChatBot

    alarm_thread = threading.Thread(target=alarm_runner, args=(alarm_clock,), daemon=True)
    reminder_thread = threading.Thread(target=reminder_runner, args=(reminder,), daemon=True)

    alarm_thread.start()
    reminder_thread.start()

    # Pass the chatbot instance to the user_interface function
    user_interface(similarity_processor, alarm_clock, reminder, timer, weather, facts_and_jokes, song_player, chatbot)

    print("Waiting for the alarm and reminder threads to finish...")
    alarm_thread.join()
    reminder_thread.join()

