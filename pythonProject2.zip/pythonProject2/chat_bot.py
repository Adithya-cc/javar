from ollama import chat

class ChatBot:
    def __init__(self, model='llama3.2'):
        """Initialize the ChatBot with a default model (llama3.2)."""
        self.model = model

    def chat_with_ollama(self, user_input):
        """Send the user input to Ollama and get the response."""
        try:
            # Send the user input to Ollama and get the response
            response = chat(model=self.model, messages=[{'role': 'user', 'content': user_input}])
            return response.message.content
        except Exception as e:
            print(f"Error while communicating with Ollama: {e}")
            return "I'm sorry, there was an error communicating with the chatbot."


