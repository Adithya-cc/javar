import re
import time
import pygame
import datetime

class Timer:
    def __init__(self, sound_file="timer.mp3"):
        self.sound_file = sound_file
        pygame.mixer.init()

    def countdown(self, hours, minutes, seconds):
        total_seconds = hours * 3600 + minutes * 60 + seconds

        while total_seconds:
            hrs, rem = divmod(total_seconds, 3600)
            mins, secs = divmod(rem, 60)
            timer = f'{hrs:02}:{mins:02}:{secs:02}'
            print(f"Time remaining: {timer}", end='\r')  # Overwrite previous line
            time.sleep(1)
            total_seconds -= 1

        print("Time remaining: 00:00:00")
        print("Time's up!")
        pygame.mixer.music.load(self.sound_file)
        pygame.mixer.music.play()

        # Wait for sound to finish
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

    def start_timer(self, time_input):
        hours, minutes, seconds = map(int, time_input.split(":"))
        self.countdown(hours, minutes, seconds)


def time_runner(va, user_input, timer):
    # Regular expressions to extract hours, minutes, and seconds from the user input
    time_pattern = re.compile(r"(\d+)\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|sec?)", re.IGNORECASE)
    
    hours = minutes = seconds = 0  # Default values
    
    matches = time_pattern.findall(user_input)
    
    for match in matches:
        value = int(match[0])
        unit = match[1].lower()
        
        if 'hour' in unit:
            hours = value
        elif 'minute' in unit:
            minutes = value
        elif 'second' in unit:
            seconds = value
    
    if hours == 0 and minutes == 0 and seconds == 0:
        va.speak("No valid time detected. Exiting.")
        return

    # Construct the time in HH:MM:SS format
    time_str = f"{hours:02}:{minutes:02}:{seconds:02}"
    va.speak(f"Timer set for {time_str}")
    timer.start_timer(time_str)  # Pass the formatted time string to the timer

