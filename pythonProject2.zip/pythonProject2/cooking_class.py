import requests
from run import VoiceAssistant

# Initialize the voice assistant (assuming this class is available in 'run')
va = VoiceAssistant()

class IndianCookingBot:
    def __init__(self, api_key="sBebQvvfkR98Id/En4EGJA==rbpIYD4ZPrsHnPAS"):
        self.api_url = "https://api.api-ninjas.com/v1/recipe"
        self.headers = {"X-Api-Key": api_key}

    def search_recipes(self, query, cuisine="Indian", max_results=5):
        """Search for Indian recipes using Ninja API."""
        params = {
            "query": query,
            "cuisine": cuisine,
        }
        response = requests.get(self.api_url, headers=self.headers, params=params)
        if response.status_code == 200:
            results = response.json()
            if results:
                # Adjust response processing according to Ninja API format
                return [
                    {
                        "title": r["title"],
                        "instructions": r.get("instructions", "No instructions available")
                    }
                    for r in results[:max_results]
                ]
            return "No recipes found for your query."
        else:
            return f"Error: {response.status_code} - {response.text}"

    def help_cook(self,user_input):
        """Main conversational interface for the bot."""
        print("Namaste! I'm your Indian cooking assistant. How can I help you today?")
        # Only ask for "Find a recipe"
        print("\n1. Find a recipe (Indian cuisine)")
        query = user_input
        recipes = self.search_recipes(query)
        if isinstance(recipes, str):
            return(recipes)
        else:
            first_recipe = recipes[0]
            return(f"To Make {first_recipe['title']}\n   {first_recipe['instructions']}")
            


