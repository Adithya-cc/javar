import datetime
from alarm_class_program import AlarmClock
from reminder_class import Reminder
from timer import Timer
from weather_class import Weather
from facts_class import FactsAndJokes
from music_class import SpotifyPlayer
from Similarity_command import SimilarityProcessor

# Action Handler function
def handle_user_action(user_input, va, similarity_processor, alarm_clock, reminder, timer, weather, facts_and_jokes, song_player):
    """
    Processes user input to detect the keyword and calls the appropriate function for the action.
    """
    # Use SimilarityProcessor to detect the keyword in user input
    detected_keyword = similarity_processor.process_user_input(user_input)

    actions = {
        "alarm": lambda: add_alarm(alarm_clock, va),
        "reminder": lambda: add_reminder(reminder, va),
        "timer": lambda: timer.start_timer(input("Enter countdown time (HH:MM:SS):")),
        "weather": lambda: weather.get_weather(input("Enter location: ")),
        "facts": lambda: fact_runner(facts_and_jokes, va),
        "joke": lambda: joke_runner(facts_and_jokes, va),
        "music": lambda: music_play_runner(song_player, va),
        "musicS": lambda: music_stop_runner(song_player),
        "time": lambda: time_runner(va),
        "date": lambda: date_runner(va),
        "timendate": lambda: time_and_date_runner(va),
    }

    if detected_keyword:
        action = actions.get(detected_keyword)
        if action:
            action()
        else:
            print("No action detected.")
    else:
        print("Switching to conversational mode...")
        va.speak("I couldn't detect any action. Let's chat!")
        return None

# Function for adding an alarm
def add_alarm(alarm_clock, va):
    va.speak("Enter alarm time (HH:MM): ")
    time_input = input("Enter alarm time (HH:MM): ")
    va.speak("Enter date (YYYY-MM-DD) or leave blank for today: ")
    date_input = input("Enter date (YYYY-MM-DD) or leave blank for today: ")
    alarm_clock.add_alarm(time_input, date_input if date_input else None)

# Function for adding a reminder
def add_reminder(reminder, va):
    va.speak("Enter reminder time (HH:MM): ")
    time_input = input("Enter reminder time (HH:MM): ")
    va.speak("Enter date (YYYY-MM-DD) or leave blank for today: ")    
    date_input = input("Enter date (YYYY-MM-DD) or leave blank for today: ")
    va.speak("Enter reminder description: ")
    description = input("Enter reminder description: ")
    reminder.add_reminder(time_input, description, date_input if date_input else None)

# Utility functions
def time_runner(va):
    print(f"The current time is: {datetime.datetime.now().strftime('%H:%M:%S')}")
    va.speak(f"The current time is: {datetime.datetime.now().strftime('%H:%M:%S')}")

def date_runner(va):
    print(f"Today's date is: {datetime.datetime.now().strftime('%Y-%m-%d')}")
    va.speak(f"Today's date is: {datetime.datetime.now().strftime('%Y-%m-%d')}")

def time_and_date_runner(va):
    now = datetime.datetime.now()
    print(f"Current time and date: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    va.speak(f"Current time and date: {now.strftime('%Y-%m-%d %H:%M:%S')}")

def fact_runner(facts_and_jokes, va):
    fact = facts_and_jokes.get_random_fact()
    print(f"Random Fact: {fact}")
    va.speak(f"Random Fact: {fact}")

def joke_runner(facts_and_jokes, va):
    joke = facts_and_jokes.get_random_joke()
    print(f"Random Joke: {joke}")
    va.speak(f"Random Joke: {joke}")

def music_play_runner(song_player, va):
    va.speak("Enter the name of the song you want to play: ")
    track_name = input("Enter the name of the song you want to play: ")
    song_player.stop_playback()
    song_player.search_and_play(track_name)

def music_stop_runner(song_player):
    song_player.stop_playback()

