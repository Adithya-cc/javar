import dateparser
import re 
from datetime import datetime, time
from alarm_class_program import AlarmClock
from reminder_class import Reminder
from timer import Timer
from weather_class import Weather
from facts_class import FactsAndJokes
from music_class import SpotifyPlayer
from Similarity_command import SimilarityProcessor
from cooking_class import IndianCookingBot
from Calculation_class import WolframAlphaConversationalAPI

# Action Handler function
def handle_user_action(user_input, va, similarity_processor, alarm_clock, reminder, timer, weather, facts_and_jokes, song_player):
    """
    Processes user input to detect the keyword and calls the appropriate function for the action.
    """
    # Use SimilarityProcessor to detect the keyword in user input
    detected_keyword = similarity_processor.process_user_input(user_input)

    actions = {
        "alarm": lambda: add_alarm(alarm_clock, va, user_input),
        "reminder": lambda: set_reminder(reminder, va, user_input),
        "timer": lambda: time_runner(va, user_input, timer),
        "weather": lambda: weather.get_weather("Ahmedabad"),
        "facts": lambda: fact_runner(facts_and_jokes, va),
        "joke": lambda: joke_runner(facts_and_jokes, va),
        "music": lambda: music_play_runner(song_player, va),
        "stop music": lambda: music_stop_runner(song_player),
        "time": lambda: time_runner(va),
        "date": lambda: date_runner(va),
        "timendate": lambda: time_and_date_runner(va),
        "recipe": lambda: handle_recipe_action(user_input, va, recipe_actions),
        "calculation": lambda: calculate_expression(user_input, va, calculator),
    }
    #keysl = ['alarm', 'reminder', 'timer', 'weather', 'facts', 'joke', 'music', 'stop music', 'time', 'date', 'timendate', 'recipe', 'calculation']

    if detected_keyword:
        action = actions.get(detected_keyword)
        if action:
            action()
        else:
            print("No action detected.")
    else:
        #print("Switching to conversational mode...")
        #va.speak("I couldn't detect any action. Let's chat!")
        return None

# Function for adding an alarm
def add_alarm(alarm_clock, va, user_input):
    # Attempt to parse the input for date and time
    parsed_datetime = dateparser.parse(user_input, settings={'PREFER_DATES_FROM': 'future'})

    # Extract date and time if found
    alarm_date = parsed_datetime.strftime('%Y-%m-%d') if parsed_datetime else None
    alarm_time = (
        parsed_datetime.strftime('%H:%M')  # 24-hour format
        if parsed_datetime and parsed_datetime.time() != time.min
        else None
    )

    # If time is missing, prompt the user for it
    if not alarm_time:
        va.speak("Please specify the alarm time in 24-hour format.")
        alarm_time_input = va.listen()
        parsed_time = dateparser.parse(alarm_time_input)

        if parsed_time and parsed_time.time() != time.min:
            alarm_time = parsed_time.strftime('%H:%M')  # Convert to 24-hour format
        else:
            va.speak("Sorry, I couldn't understand the time. Alarm not set.")
            return

    # Confirm and set the alarm
    if alarm_date:
        va.speak(f"Setting an alarm for {parsed_datetime.strftime('%A, %d %B %Y')} at {alarm_time} (24-hour time).")
    else:
        va.speak(f"Setting an alarm for today at {alarm_time} (24-hour time).")

    alarm_clock.add_alarm(alarm_time, alarm_date)


def set_reminder(reminder, va, user_input):
    parsed_datetime = dateparser.parse(user_input, settings={'PREFER_DATES_FROM': 'future'})
    reminder_date = parsed_datetime.strftime('%Y-%m-%d') if parsed_datetime else None
    reminder_time = (
        parsed_datetime.strftime('%H:%M')  # 24-hour format
        if parsed_datetime and parsed_datetime.time() != time.min
        else None
    )

    # If time is not found in user input
    if not reminder_time:
        va.speak("I couldn't understand the time. Please specify the reminder time.")
        time_input = va.listen()
        parsed_time = dateparser.parse(time_input, settings={'PREFER_DATES_FROM': 'future'})

        if parsed_time and parsed_time.time() != time.min:
            reminder_time = parsed_time.strftime('%H:%M')  # Convert to 24-hour format
        else:
            va.speak("Sorry, I couldn't understand the time. Reminder not set.")
            return

    # If no description was provided, prompt the user
    va.speak("What should the reminder say?")
    description = va.listen().strip()
    if not description:
        va.speak("Reminder description cannot be empty. Please try again.")
        return

    # Confirm the reminder details
    if reminder_date:
        va.speak(f"Setting a reminder for {parsed_datetime.strftime('%A, %d %B %Y')} at {reminder_time} with the description: {description}.")
    else:
        va.speak(f"Setting a reminder for today at {reminder_time} with the description: {description}.")

    # Add the reminder
    reminder.add_reminder(reminder_time, description, reminder_date)



# Utility functions
def time_runner(va, user_input, timer):
    # Regex pattern to match time format like "1 hr 2 min 30 sec", "10 sec", or "1 hr"
    time_pattern = re.compile(r"(?:(\d+)\s*hr\s*)?(?:(\d+)\s*min\s*)?(\d+)\s*sec")
    
    # Search for the time in the user input
    match = time_pattern.search(user_input.lower())  # Ensure input is case-insensitive
    print(match)
    if match:
        # Extract hours, minutes, and seconds from the user input
        hours = int(match.group(1) or 0)  # Default to 0 if hours are not provided
        minutes = int(match.group(2) or 0)  # Default to 0 if minutes are not provided
        seconds = int(match.group(3))  # Seconds are always provided

        # Format time to HH:MM:SS
        formatted_time = f"{hours:02}:{minutes:02}:{seconds:02}"

        # Call the start_timer method from Timer class
        timer.start_timer(formatted_time)
        va.speak(f"Timer set for {formatted_time}")
    else:
        va.speak("No time detected. Please specify the time you want to set the timer for.")
        print("No time detected. Asking user for input.")
        
        # Ask the user to input the time again
        user_input_time = va.listen()  # Assume this listens to the user input again
        time_runner(va, user_input_time, timer) 
        
def date_runner(va):
    print(f"Today's date is: {datetime.datetime.now().strftime('%Y-%m-%d')}")
    va.speak(f"Today's date is: {datetime.datetime.now().strftime('%Y-%m-%d')}")

def time_and_date_runner(va):
    now = datetime.datetime.now()
    print(f"Current time and date: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    va.speak(f"Current time and date: {now.strftime('%Y-%m-%d %H:%M:%S')}")

def fact_runner(facts_and_jokes, va):
    fact = facts_and_jokes.get_random_fact()
    print(f"Random Fact: {fact}")
    va.speak(f"Hear is a Fact: {fact}")

def joke_runner(facts_and_jokes, va):
    joke = facts_and_jokes.get_random_joke()
    print(f"Random Joke: {joke}")
    va.speak(f"A joke for you: {joke}")

def music_play_runner(song_player, va):
    va.speak("Enter the name of the song you want to play: ")
    song_name = va.listen()
    song_player.stop_playback()
    song_player.search_and_play(song_name)
    va.speak(f"Now playing: {song_name}")

def music_stop_runner(song_player):
    song_player.stop_playback()
print("Available languages:")
    for name, code in chatbot.languages.items():
        print(f"- {name.capitalize()} ({code})")

    try:
        source_language = input("\nEnter the source language (e.g., 'English', 'Tamil'): ").strip()
        target_language = input("Enter the target language (e.g., 'Hindi', 'French'): ").strip()
        chatbot.set_languages(source_language, target_language)
        chatbot.start_chat()
    except ValueError as e:
        print(e)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def handle_recipe_action(user_input, va, recipe_actions):
    """
    This function handles the recipe-related user actions based on the user's input.
    """
    user_input = user_input.lower()  # Convert input to lowercase for easier matching
    cook = IndianCookingBot()
    va.speak(cook.help_cook(user_input))
    
def calculate_expression(user_input, va, calculator):
    calc = va.listen()
    va.speak(WolframAlphaConversationalAPI.query(user_input))


