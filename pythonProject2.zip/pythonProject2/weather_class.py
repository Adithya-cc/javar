import requests
from geopy.geocoders import Nominatim
from run import VoiceAssistant



class Weather:
    def __init__(self):
        self.api_key = "470830cc073b47507d2edbe1d39e9e74"  # Replace with your OpenWeatherMap API key

    def get_coordinates(self):
        # Use a public geolocation API to get latitude and longitude
        try:
            response = requests.get("https://ipinfo.io", timeout=5)
            data = response.json()
            coordinates = data["loc"].split(",")  # Extract latitude and longitude
            return float(coordinates[0]), float(coordinates[1])
        except Exception as e:
            print(f"Error getting coordinates: {e}")
            return None, None

    def get_weather(self, location="Ahmedabad"):
        if location == "":
            location = None

        if location is None:
            # Get latitude and longitude
            lat, lon = self.get_coordinates()
            if lat is None or lon is None:
                return "Could not detect your location. Please provide a valid city name."

            # Reverse geocoding to find the city name
            geolocator = Nominatim(user_agent="weather_app")
            location_data = geolocator.reverse((lat, lon), exactly_one=True)
            # Extract the city or town name
            location = location_data.raw.get("address", {}).get("city") or \
                       location_data.raw.get("address", {}).get("town") or \
                       location_data.raw.get("address", {}).get("village")

            if not location:
                return "Could not extract a valid city from your location. Please try entering a city manually."

            print(f"Detected location: {location}")

        # Fetch weather data from OpenWeatherMap
        url = f"http://api.openweathermap.org/data/2.5/weather?q={location}&appid={self.api_key}&units=metric"
        response = requests.get(url)
        data = response.json()

        if data['cod'] == 200:
            weather = data['weather'][0]['description']
            temp = data['main']['temp']
            return f"The weather in {location} is {weather} with a temperature of {temp}°C."
        else:
            return f"Could not get weather data for {location}. Please check the location or try again later."

# Example Usage for Ahmedabad
va = VoiceAssistant()
weather = Weather()
print(weather.get_weather("Ahmedabad"))
va.speak(weather.get_weather("Ahmedabad"))

