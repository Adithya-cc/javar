import requests


class WolframAlphaConversationalAPI:
    def __init__(self):
        self.base_url = "https://api.wolframalpha.com/v1/conversation.jsp"
        self.app_id = "8W267E-5XL3LLAVL4"
        self.conversation_state = None  # For maintaining conversational context

    def query(self, input_query):
        params = {
            'appid': self.app_id,
            'i': input_query,  # The input query
        }

        # Include conversation state if it exists (for follow-up queries)
        if self.conversation_state:
            params['conversationid'] = self.conversation_state

        try:
            # Send GET request to the Wolfram Alpha Conversational API
            response = requests.get(self.base_url, params=params)
            response.raise_for_status()  # Raise HTTPError for bad responses

            # Parse the JSON response
            data = response.json()

            # Update the conversation state
            self.conversation_state = data.get('conversationID')

            # Return only the result
            return data.get('result', "No result found.")
        except requests.exceptions.RequestException as e:
            return f"Error: {e}"
