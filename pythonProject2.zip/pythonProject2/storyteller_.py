import openai
import random
import time

# Set up OpenAI API key
openai.api_key = "sk-proj-_cIG7nE5Udzv-4qhvNTnnLKNoa_NvMDsWbX635pviHPCIQS70XRMddRbMr8SG-oMuIRyB0XmWBT3BlbkFJNFQb2Zv5tFYQFxWL0A0I-PiaKTKkUecgpKNdhMbP4nyZxDOECwsNDiD5MoAP2B0z4urgslWQcAs"


class InteractiveStoryBot:
    def __init__(self):
        self.compliments = [
            "You're so creative!",
            "I love how imaginative you are!",
            "You're doing awesome!",
            "What a fantastic choice!",
            "You're a great adventurer!"
        ]

    def get_time_of_day(self):
        current_hour = time.localtime().tm_hour
        if current_hour < 12:
            return "morning"
        elif 12 <= current_hour < 18:
            return "afternoon"
        else:
            return "evening"

    def generate_story(self, user_input):
        # Construct a prompt based on the user input
        prompt = f"You are an AI storyteller. Create an interactive, dynamic story based on this input: {user_input}. The story should flow with engaging dialogue and include choices for the user. Make the responses interactive and friendly."

        # Send the prompt to the OpenAI API to generate the story using the new interface
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # or whichever model you prefer
            messages=[
                {"role": "system", "content": "You are a helpful and interactive storyteller."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=200,
            temperature=0.7
        )

        # Get the text response from OpenAI
        story = response['choices'][0]['message']['content'].strip()
        return story

    def start_interactive_story(self):
        print("Welcome to the interactive storytelling experience!")
        print("I'll guide you through a dynamic adventure based on your choices.")

        while True:
            # Ask for the user's input
            user_input = input("What do you want to do next? (e.g., 'explore the forest', 'ask for help') ")

            # If the user wants to exit the story loop
            if user_input.lower() in ['exit', 'quit', 'bye']:
                print("Thanks for playing! Have a great day!")
                break

            # Generate a story based on user input using OpenAI
            story = self.generate_story(user_input)

            # Display the generated story
            print(f"\n{story}")

            # Give the user a compliment based on their choice
            compliment = random.choice(self.compliments)
            print(f"\n{compliment}\n")


# Start the interactive story bot
bot = InteractiveStoryBot()
bot.start_interactive_story()
