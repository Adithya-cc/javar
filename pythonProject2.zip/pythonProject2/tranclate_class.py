import speech_recognition as sr
from translate import Translator
from gtts import gTTS
from playsound import playsound

def text_to_speech(text):
    """Converts text to speech using gTTS and plays it using playsound."""
    tts = gTTS(text=text, lang='en')
    tts.save("output.mp3")
    playsound("output.mp3")  # Play the generated audio file

def recognize_speech():
    """Captures speech input from the user and converts it to text."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for your speech...")
        text_to_speech("Please speak now.")
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            print("Recognizing your speech...")
            text = recognizer.recognize_google(audio)
            print(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            text_to_speech("Sorry, I did not understand that. Please try again.")
            return None
        except sr.RequestError:
            text_to_speech("Sorry, my speech service is down.")
            return None
        except Exception as e:
            text_to_speech(f"An error occurred: {str(e)}")
            return None

def translate_text(text, target_language):
    """Translates the given text into the specified language using the translate library."""
    translator = Translator(to_lang=target_language)
    try:
        translated = translator.translate(text)
        print(f"Translated text: {translated}")
        text_to_speech(translated)
        return translated
    except Exception as e:
        text_to_speech(f"An error occurred during translation: {str(e)}")
        return None

def main():
    text_to_speech("Welcome to the speech translation program.")
    
    # List of supported languages in translate library
    available_languages = {
        "en": "English",
        "de": "German",
        "fr": "French",
        "es": "Spanish",
        "it": "Italian",
        "pl": "Polish",
        "nl": "Dutch",
        "ru": "Russian",
        "ja": "Japanese",
        "ta": "Tamil",  # Added Tamil (or other languages you need)
        "zh": "Chinese"
    }
    
    print("Available languages:")
    for lang_code, lang_name in available_languages.items():
        print(f"{lang_name} ({lang_code})")

    text_to_speech("Please speak the sentence and the language code you want to translate it to. For example, translate 'What are you doing?' to Tamil.")
    user_input = recognize_speech()

    if not user_input:
        text_to_speech("No sentence captured. Exiting the program.")
        return

    # Example input: "Translate what are you doing to Tamil"
    # Extracting the sentence and target language
    user_input = user_input.lower()
    for lang_code in available_languages:
        if lang_code in user_input:
            sentence = user_input.split(f"to {available_languages[lang_code].lower()}")[0].strip()
            target_language_code = lang_code
            print(f"Detected sentence: {sentence}")
            print(f"Target language: {available_languages[target_language_code]}")
            text_to_speech(f"Translating {sentence} to {available_languages[target_language_code]}.")
            translate_text(sentence, target_language_code)
            return
    
    text_to_speech("Could not detect a valid language code. Please try again.")
    print("Could not detect a valid language code.")

if __name__ == "__main__":
    main()

