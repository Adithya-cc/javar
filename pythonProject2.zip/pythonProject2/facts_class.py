import requests

class FactsAndJokes:
    def __init__(self):
        self.api_url_facts = 'https://api.api-ninjas.com/v1/facts'
        self.api_url_jokes = 'https://v2.jokeapi.dev/joke/Any'  # Updated Joke API URL
        self.headers = {
            "X-Api-Key": "sBebQvvfkR98Id/En4EGJA==rbpIYD4ZPrsHnPAS"  # Your API Key
        }

    def get_random_fact(self):
        """
        Fetch a random fact from the Facts API.
        """
        try:
            response = requests.get(self.api_url_facts, headers=self.headers)
            print("Fact API Response Code:", response.status_code)  # Debugging
            if response.status_code == 200:
                fact_data = response.json()
                if isinstance(fact_data, list) and len(fact_data) > 0:
                    fact = fact_data[0].get('fact', 'No fact found.')
                    return fact
                else:
                    return "No fact found in response."
            else:
                # Return the error message from the response body
                return f"Error fetching fact: {response.status_code} - {response.text}"
        except Exception as e:
            return f"An error occurred: {str(e)}"

    def get_random_joke(self):
        """
        Fetch a random joke from JokeAPI.
        """
        try:
            response = requests.get(self.api_url_jokes)
            print("Joke API Response Code:", response.status_code)  # Debugging
            if response.status_code == 200:
                joke_data = response.json()
                if joke_data.get('type') == 'single':
                    return joke_data['joke']
                elif joke_data.get('type') == 'twopart':
                    return f"{joke_data['setup']} - {joke_data['delivery']}"
                else:
                    return "No joke found."
            else:
                return "Could not fetch random joke. Try again later."
        except Exception as e:
            return f"An error occurred: {str(e)}"

    def get_fact_or_joke(self, topic=None, is_joke=False):
        """
        Fetch a random fact or joke based on user input.
        """
        if is_joke:
            return self.get_random_joke()
        else:
            return self.get_random_fact()


