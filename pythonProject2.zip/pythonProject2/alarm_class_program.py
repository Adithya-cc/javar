import json
from datetime import datetime, timedelta
import pygame
import time


class AlarmClock:
    def __init__(self, log_file="alarms.txt", sound_file=r"C:\Users\adith\PycharmProjects\pythonProject2\old_alarm_sound.mp3"):
        self.log_file = log_file
        self.sound_file = sound_file
        pygame.mixer.init()

    def read_alarms(self):
        try:
            with open(self.log_file, "r") as file:
                alarms = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            alarms = []
        return alarms

    def save_alarms(self, alarms):
        with open(self.log_file, "w") as file:
            json.dump(alarms, file, indent=4)

    def add_alarm(self, time_input, date_input=None):
        now = datetime.now()
        try:
            if date_input:
                alarm_time = datetime.strptime(f"{date_input} {time_input}", "%Y-%m-%d %H:%M")
            else:
                alarm_time = datetime.strptime(time_input, "%H:%M")
                alarm_time = alarm_time.replace(year=now.year, month=now.month, day=now.day)
                if alarm_time < now:
                    alarm_time += timedelta(days=1)

            alarms = self.read_alarms()

            for alarm in alarms:
                existing_alarm_time = datetime.strptime(alarm["time"], "%Y-%m-%d %H:%M")
                if existing_alarm_time == alarm_time and alarm["active"]:
                    print(f"An alarm is already set for {alarm_time.strftime('%Y-%m-%d %H:%M')}.")
                    return

            alarms.append({"time": alarm_time.strftime("%Y-%m-%d %H:%M"), "active": True})
            self.save_alarms(alarms)
            print(f"Alarm added for {alarm_time.strftime('%Y-%m-%d %H:%M')}.")
        except ValueError:
            print("Invalid time format. Use 'HH:MM' or provide a valid date and time.")

    def deactivate_alarm(self, date_time):
        alarms = self.read_alarms()
        for alarm in alarms:
            if alarm["time"] == date_time:
                if not alarm["active"]:
                    print(f"Alarm for {date_time} is already deactivated.")
                    return
                alarm["active"] = False
                self.save_alarms(alarms)
                print(f"Alarm for {date_time} deactivated.")
                return
        print(f"No alarm found for {date_time}.")

    def get_next_alarm(self):
        alarms = self.read_alarms()
        active_alarms = [a for a in alarms if a["active"]]
        if not active_alarms:
            return None
        active_alarms.sort(key=lambda x: datetime.strptime(x["time"], "%Y-%m-%d %H:%M"))
        return active_alarms[0]

    def play_alarm_sound(self):
        print("Time to wake up!")
        pygame.mixer.music.load(self.sound_file)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

    def alarm_function(self):
        while True:
            next_alarm = self.get_next_alarm()
            if not next_alarm:
                #print("No active alarms.")
                time.sleep(10)
                continue

            alarm_time = datetime.strptime(next_alarm["time"], "%Y-%m-%d %H:%M")
            now = datetime.now()

            if alarm_time <= now:  # If the alarm time has passed, play the sound
                print(f"Alarm for {next_alarm['time']} is now active!")
                self.play_alarm_sound()  # Play the sound
                self.deactivate_alarm(next_alarm["time"])  # Deactivate the alarm after playing the sound
                continue

            time_to_wait = (alarm_time - now).total_seconds()
            if time_to_wait > 0:
                time.sleep(1)

    def run(self):
        """Run the alarm checking functionality."""
        try:
            self.alarm_function()
        except KeyboardInterrupt:
            print("\nAlarm system stopped.")
